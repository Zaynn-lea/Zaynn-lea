

# Answer from the 2 (A vous...) part :


## 2 : 

### a :

On remarque des différneces dans l'intensité et la répartition des couleurs.

### b :

Avec la shere, on obtient des résultats radicalement différents entre les deux méthodes.

### c :

Pour avoir une carte de couleur représentant la différence entre les 2 méthodes, on commence par calculer le résultat de chacune des deux méthodes. Ensuite on les normalise entre 0 et 1. Puis on prends la différence en absolu entre les deux et on créer notre carte de couleurs à partir de cette valeur.

### d :

La surface est un peu folle et dépasse du modèle lorsque l'on s'éloigne du voisinage (exemple oreilles).

### e :

On remarque que la différence viens du degrès des noeuds : les degres extremes ont plus de différences.

### g :

Depuis le point de courbure importante, on check la courbure des sommets du voisinage immediats et on prend les sommets de courbures maximals.
On repète en gardant en mémoire les sommets faisant partie de la ligne saillante pour ne pas repasser dessus.


