//
//  mesh_functions.hpp
//  test1
//
//  Created by Bac Alexandra on 17/02/2022.
//

#ifndef mesh_functions_hpp_2
#define mesh_functions_hpp_2

#include <iostream>
#include <limits>
#include <random>
#include "starter_defs.h"
#include <CGAL/IO/Color.h>

using namespace std ;


std::vector<Mesh::Vertex_index> vneigh(Mesh::Vertex_index, Mesh&);

double curvature(Mesh::Vertex_index, Mesh&);

// CGAL::Color color_ramp(double vmin, double vmax, double mean, double stdev, double v, CGAL::Color col1, CGAL::Color col2);

#endif /* mesh_functions_hpp_2 */ 
