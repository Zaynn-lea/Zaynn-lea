//
//  test1.cpp
//  
//
//  Created by Bac Alexandra on 11/02/2022.
//

#include <iostream>
#include <cstdlib>
#include <limits>
#include <random>
#include <CGAL/Simple_cartesian.h>
#include <CGAL/Surface_mesh.h>
#include <CGAL/boost/graph/IO/polygon_mesh_io.h>
#include <CGAL/IO/Color.h>
#include <CGAL/Kernel/global_functions.h>
#include "starter_defs.h"
#include "mesh_functions.hpp"
#include "mesh_functions_TP1.hpp"
#include "distrib.hpp"
#include "courbures.h"


using namespace std ;


int main(int argc, char** argv)
{
	Mesh m;
	string fname ;
	if (argc != 2)
	{
		cout << "Wrong number of arguments: code_courb filename" << endl ;
		return EXIT_FAILURE;
	}
	else
	{
		fname = argv[1] ;
	}
	
	if(!CGAL::IO::read_polygon_mesh(fname, m))
	{
		std::cerr << "Invalid input file." << std::endl;
		return EXIT_FAILURE;
	}
	
    // Calcul des tenseurs de courbure en chaque point (par ajustement de surface quadratique)
    cout << "----- Starting curvature computation" << endl ;
    MyMesh mym(m) ;
    MyMesh_Norm mymn(mym) ;
    MyMesh_Courb mymc(mymn) ;
    MyMesh_Quad mymq(mymn) ;
    
    // Colors from curvature
    mymq.fit_quads() ;
    std::function<Tcourb(Mesh::Vertex_index)> func = [&] (Mesh::vertex_index v) {return mymq.princip_curv(v) ;} ;
    mymc.set_courbs(func) ;
    mymc.set_K_colors() ;
    mymn.output_mesh("mesh_with_normal.off") ;
    mymc.output_mesh("mesh_with_K.off", "mesh_with_principal_dirs.off") ;


    // TP1 :
	Mesh::Property_map<vertex_descriptor,CGAL::Color> color;
        Mesh::Property_map<vertex_descriptor, unsigned int> degree;
        Mesh::Property_map<vertex_descriptor, double> curv;
        bool created_col;
        boost::tie(color, created_col) = m.add_property_map<vertex_descriptor,CGAL::Color>("v:color",CGAL::Color());
        assert(created_col);

        bool created_deg;
        boost::tie(degree, created_deg) = m.add_property_map<vertex_descriptor, unsigned int>("v:degree", int());
        assert(created_deg);

        bool created_curv;
        boost::tie(curv, created_curv) = m.add_property_map<vertex_descriptor, double>("v:curv", double());
        assert(created_curv);

        Mesh::Vertex_range r = m.vertices();
        Mesh::Vertex_range::iterator it = r.begin();
        int val;
        unsigned int maxi = vneigh(*it, m).size();
        unsigned int mini = maxi; 
        std::vector<Mesh::Vertex_index> vec;
        distrib<double> d;


    cout << "----- Writting to off file a quadrtic patch" << endl ;
    // Tirage aléatoire de points
    int nv = m.vertices().size() ;

    std::random_device rd; // obtain a random number from hardw    are
    std::mt19937 gen(rd()); // seed the generator
    std::uniform_int_distribution<> distr(0, nv-1); // define the range
/*
    int ni = distr(gen) ;
    Mesh::Vertex_index vi(ni) ;
    MyQuad *qp = mymq.q[vi] ;
    Mesh &mi(qp->local_mesh(.1, 8)) ;
    CGAL::IO::write_polygon_mesh("sample_quad.off", mi) ;
*/

    // Tirage de 10 points :
    std::vector<Mesh::Vertex_index> verts;
    for (Mesh::Vertex_index v : m.vertices()) {
    	verts.push_back(v);
    }

    std::sort(verts.begin(), verts.end(),
        [&mymc](Mesh::Vertex_index v1, Mesh::Vertex_index v2) {
		return mymc.getK(v1) > mymc.getK(v2);
	}
    );

	for (int i = 0; i < 5; i++)
	{
		Mesh::Vertex_index vi(verts[i]) ;
    		MyQuad *qp = mymq.q[vi] ;
    		Mesh &mi(qp->local_mesh(.1, 8)) ;
		CGAL::IO::write_polygon_mesh("sample_quad" + std::to_string(i) + ".off", mi) ;
	}
	for (int i = verts.size() -1; i >= verts.size() - 5; i--)
	{
		Mesh::Vertex_index vi(verts[i]) ;
    		MyQuad *qp = mymq.q[vi] ;
    		Mesh &mi(qp->local_mesh(.1, 8)) ;
		CGAL::IO::write_polygon_mesh("sample_quad" + std::to_string(i) + ".off", mi) ;
	}


	CGAL::Color color1 = CGAL::Color(0, 255, 0) ;
	CGAL::Color color2 = CGAL::Color(255, 0, 0) ;
	CGAL::Color color3 = CGAL::Color(0, 0, 255) ;

	for (it = r.begin(); it != r.end(); it++)
	{
		// cout << mymc.k1[*it] << endl;
		//
		// We can replace k1 by k2

		if (mymc.k1[*it] > 0)
		{
			color[*it] = color1;
		}
		else if (mymc.k1[*it] < 0)
		{
			color[*it] = color2;
		}
		else
		{
			color[*it] = color3;
		}
	}

        CGAL::IO::write_polygon_mesh("node_type.off", m, CGAL::parameters::vertex_color_map(color)) ;


	// TP1 :
	//
        // Parcours simple du maillage
        for( it = r.begin(); it != r.end() ; ++it)
        {
                degree[*it] = vneigh(*it, m).size();
                curv[*it]   = curvature(*it, m);
                d.add_data(curv[*it]);
                if (maxi < degree[*it]) maxi = degree[*it];
                if (mini > degree[*it]) mini = degree[*it];
        }


        for(it = r.begin() ; it != r.end() ; ++it)
        {
                val = (int) (255.0 * (double) (degree[*it] - mini) / (double) maxi);
                color[*it] = CGAL::Color(val, val, val) ;
                cout << "vertex : " << *it << endl ;
        }

        CGAL::IO::write_polygon_mesh("degree.off", m, CGAL::parameters::vertex_color_map(color)) ;


        double kmean   = d.get_mean();
        double kmin    = d.get_min();
        double kmax    = d.get_max();
        double kstddev = d.get_stdev();

        for(it = r.begin() ; it != r.end() ; ++it)
        {
                color[*it] = color_ramp(kmin, kmax, kmean, kstddev, curv[*it], CGAL::blue(), CGAL::red());
                cout << "vertex : " << *it << endl ;
        }

        CGAL::IO::write_polygon_mesh("curvature.off", m, CGAL::parameters::vertex_color_map(color)) ;


	
	// Curvature comparaison
	
        Mesh::Property_map<vertex_descriptor, double> curv1;
        boost::tie(curv1, created_curv) = m.add_property_map<vertex_descriptor, double>("v:curv2", double());
        assert(created_curv);
        Mesh::Property_map<vertex_descriptor, double> curv2;
	boost::tie(curv2, created_curv) = m.add_property_map<vertex_descriptor, double>("v:curv1", double());
        assert(created_curv);


	distrib<double> d1, d2;

	for (it = r.begin(); it != r.end(); it++)
	{
		curv1[*it] = curvature(*it, m);
                curv2[*it] = mymc.getK(*it);

		d1.add_data(curv1[*it]);
		d2.add_data(curv2[*it]);
	}


	distrib<double> d_tot;
	double c1, c2;

	for (it = r.begin(); it != r.end(); it++)
	{
		// normalise between 0 and 1
		c1 = (curv1[*it] - d1.get_min()) / d1.get_max();
		c2 = (curv2[*it] - d2.get_min()) / d2.get_max();
		
		// reusing curv2 to store the result
		curv2[*it] = std::abs(c1 - c2);
		
		d_tot.add_data(curv2[*it]);
	}


	kmean   = d_tot.get_mean();
        kmin    = d_tot.get_min();
        kmax    = d_tot.get_max();
        kstddev = d_tot.get_stdev();

	for (it = r.begin(); it != r.end(); it++)
	{
		// reusing the color map because it's the same 
		color[*it] = color_ramp(kmin, kmax, kmean, kstddev, curv2[*it], CGAL::blue(), CGAL::red());
	}

	CGAL::IO::write_polygon_mesh("curvature_comparaison.off", m, CGAL::parameters::vertex_color_map(color)) ;


	return 0;
}

