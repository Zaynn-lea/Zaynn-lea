//
//  mesh_functions.cpp
//  test1
//
//  Created by Bac Alexandra on 17/02/2022.
//

#define _USE_MATH_DEFINES

#include <algorithm>
#include <math.h>
#include <cmath>

#include "mesh_functions_TP1.hpp"


std::vector<Mesh::Vertex_index> vneigh(Mesh::Vertex_index v, Mesh &m)
{
        std::vector<Mesh::Vertex_index> vNeigh;
        Mesh::Halfedge_index he, he_init;

        he = he_init = m.opposite(m.halfedge(v));

        do
        {
                vNeigh.push_back(m.target(he));
                he = m.next(m.opposite(he));
        } while (he != he_init);

        return vNeigh;
}


double curvature(Mesh::Vertex_index v, Mesh &m)
{
        std::vector<Mesh::Vertex_index> vNeigh = vneigh(v, m);
        Mesh::Halfedge_index he, he_init;
	double sumSurface = 0.0;
	double sumAngle   = 0.0;


        he = he_init = m.opposite(m.halfedge(v));

        do
        {
		sumAngle += CGAL::approximate_angle(
			m.point(m.target(he)),
			m.point(v),
			m.point(m.target(m.next(m.opposite(he))))
		);
                sumSurface += sqrt(
			CGAL::cross_product(m.point(m.target(he)) - m.point(v),
			m.point(m.target(m.next(m.opposite(he)))) - m.point(v)).squared_length()
		);

                he = m.next(m.opposite(he));
        } while (he != he_init);


        return M_PI * (2 - sumAngle/180) / (2*sumSurface);
}


/*
CGAL::Color color_ramp(double vmin, double vmax, double mean, double stdev, double v, CGAL::Color col1, CGAL::Color col2)
{
	stdev = stdev/2 ;
	if (vmin < mean-stdev)
		vmin = mean-stdev ;
	if (vmax > mean+stdev)
		vmax = mean+stdev ;
	if (v < vmin)
		v = vmin ;
	else if (v > vmax)
		v = vmax ;
	double per ;
	CGAL::Color c ;
	CGAL::Color col_first, col_second ;
	if (v <= mean)
	{
		per = (v-vmin)/(mean-vmin) ;
		col_first = col1 ;
		col_second = CGAL::white() ;
	}
	else
	{
	per = (v-mean)/(vmax-mean) ;
	col_first = CGAL::white() ;
		col_second = col2 ;
	}
	c.red() = floor(col_first.red() + per*(col_second.red()-col_first.red())) ;
	c.green() = floor(col_first.green() + per*(col_second.green()-col_first.green())) ;
	c.blue() = floor(col_first.blue() + per*(col_second.blue()-col_first.blue())) ;
	return c ;
}
*/

